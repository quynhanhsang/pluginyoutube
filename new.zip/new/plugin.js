    /*
     * +Gallery Javascript Photo gallery v1.0.0
     *
     * Copyright 2013, Sangtran | Email:sangtrank64@gmail.com
     * Dual licensed under the MIT and GPL licenses:

     */
    (function($){
        $.fn.pluginyoutube = function(options){
            var index = this;
            var captionsLength = 100;
            if(index.length === 0){
                return false;
            }

            var pg = {
                userId:'UCwT8-xtfASMe5dGyV-cr2gQ',
                apikeys:'AIzaSyA7LV2DX6RjRJCROAQS57mqIr4CHNRU0eQ',
                limit:10,
                type:'youtube',
                imgArray:{},
                dataOption:{},
                init:function(){
                    var _doc = $(document);
                    pg.writeHTML();

                    ///get data in plguin
                    
                    pg.getdataoptions();
                   // console.log(pg.getdataoptions);
                    
                    pg.loadSingleAlbum();

                    _doc.on("click", ".pgthumb", function(e){
                        e.preventDefault();
                        var idx  = $(".pgthumb").index(this);
                        // /alert(idx);
                        pg.loadZoom(idx);
                    });

                    _doc.on("click", "#pg-zoom-ismation",function(){
                            $("body").find(this).remove();  
                    });
                },
                /*--------------------------
            
                set up the initial HTML
            
                ----------------------------*/
                getdataoptions:function(){
                    var data = options.dataOption.userId;
                    if(data){
                        pg.userId = data;
                    }else{
                        alert("Bạn nhập user id");
                        return false;
                    }

                    data = options.dataOption.apikey;
                    if(data){
                        pg.apikey = data;
                    }

                    data = options.dataOption.limit;
                    if(data){
                        pg.limit = data;
                    }
                },
                /*--------------------------
            
                set up the initial HTML
            
                ----------------------------*/
                writeHTML:function(){
                    //add div get id;
                    index.append('<div id="pgthumbview"><ul id="pgthumbs" class="clearfix"></ul></div>');
                },

                /*--------------------------
            
                Load data api youtube
            
                ----------------------------*/

                loadSingleAlbum:function(){
                    var url;
                        var API_key    = pg.apikey ;  //'AIzaSyA7LV2DX6RjRJCROAQS57mqIr4CHNRU0eQ';
                        var channelID  = pg.userId ; //'UCfVsh8oBK-Sm2IL3uRdH32g';
                        console.log(API_key);
                        var maxResults = pg.limit;
                        url = 'https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&channelId='+channelID+'&maxResults='+maxResults+'&key='+API_key+'';
                    
                    pg.loadGallery(url);
                },
                /*--------------------------
            
                Load album
            
                ----------------------------*/
                loadGallery:function(url, title){
                    var obPath,
                    imgTitle,
                    imgSrc,
                    imgBg = '',
                    imgTh;
                                    
                    pg.imgArray = [];
                    pg.titleArray = [];
                    $.ajax({
                        url: url,
                        cache:false,
                        dataType: "jsonp",
                        success: function(json){
                            var juxCrumbTitle = '';

                            console.log(json);
                            objPath= json.items;
                          
                            ///check objPath = undefined
                            if( typeof objPath !== 'undefined'){
                                pg.imgTotal = objPath.length;
                            }
                            

                            //limit the results
                            if(pg.limit < pg.imgTotal){
                                pg.imgTotal = pg.limit;
                            }
                            
                            if(pg.imgTotal === 0) {
                                alert('Ban check lại gallery');
                            }

                            jQuery.each(objPath,function(i,obj){
                                imgTitle = obj.snippet.channelTitle;
                                imgSrc = obj.id.videoId;
                                imgTh = obj.snippet.thumbnails.high.url;
      
                                if(!imgTitle) {
                                    imgTitle = '';
                                }   
                                pg.imgArray[i] = imgSrc;
                                pg.titleArray[i] = imgTitle;
                                
                                if(pg.type =='youtube'){
                                    index.find('#pgthumbs').append('<li class="pgthumb"  ><a href="' + imgSrc + '" ><img src="' + imgTh + '" id="pgthumbimg' + i + '" class="pgthumbimg" alt="' + pgShorten(imgTitle , captionsLength) + '" title="' + pgShorten(imgTitle , captionsLength) + '"' + imgBg + '><span class="pg-video-preview-play"></span></a></li>');
                     
                                } //end if(i < pg.limit)
                            }); //end each
                        } //end success                           
                    });
                    
                },
                zoomIdx: null, //the zoom index
                zoomImagesLoaded: [],           
                zoomScrollDir: null,
                zoomScrollLeft: 0,
                ///load zoom
                loadZoom: function(idx){
                    var m = $("body");
                    m.append('<div id="pg-zoom-ismation" class="pg-zoom-ismation"><div id="pg-confirmbox" class="pg-confirmbox"><iframe width="560" height="315" src="https://www.youtube.com/embed/'+ pg.imgArray[idx] +'?&fs=1" data-src="' + pg.imgArray[idx] + '" title="' + pgShorten(pg.titleArray[idx] , captionsLength) + '" alt="' + pgShorten(pg.titleArray[idx] , captionsLength) + '" id="pgzoomimg' + idx + '" class="pgzoomimg" allow="autoplay; encrypted-media" allowfullscreen> </iframe></div></div>');
                },
                removezoom:function(){
                    $("#pg-zoom-ismation").click(function(){
                        $("body").find(this).remove();  
                    });
                }
            };
            $.extend(pg, options);
            pg.init();    
        };
        function pgShorten(string, length){
            string = jQuery.trim(string);
            // Replace all bad character
            string = string.replace(/\</g,'&#60');
            string = string.replace(/\>/g,'&#62');  
            string = string.replace(/\"/g, '&#34');
            string = string.replace(/\'/g, '&#39');
            string = string.replace(/\%/g,'&#37');
            
                
            if (string.length > length)
            {
                var cut = string.substring(0, length);
                // Cut last string
                last_space_position = cut.lastIndexOf(' ');
                //      console.log(last_space_position);
                if (last_space_position < length){
                    return string.substring(0,last_space_position) + "...";
                }else{
                    return cut + '...';
                } 
            }else
                return string;
        }
    }( jQuery ));